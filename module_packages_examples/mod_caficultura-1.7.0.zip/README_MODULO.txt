RuralIA - Caficultura 1.7.0

Paquete de configuración para importar desde Administración > Módulos.
Contiene el manifiesto oficial actual: navegación, roles y permisos.
Requiere que producción ya incluya el runtime de Caficultura 1.7.0.
No contiene ni instala código Python/Vue, pantallas ni migraciones.
No actualiza una instalación con código anterior.
La importación reemplaza la configuración del manifiesto, incluidas las personalizaciones de menú, roles y permisos.
