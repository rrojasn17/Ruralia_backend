# Revisión de Caficultura — 29 de septiembre de 2026

Se conservaron los cambios que ya estaban presentes en ambos repositorios. Esta revisión completa y verifica los flujos existentes; no se desplegó ni se modificó la base de producción.

## Cambios de esta revisión

- Tema: superficies neutras, verdes de navegación y login, controles consistentes. Se conserva ámbar para advertencias y se evita aplicar la altura de inputs de texto a checkbox/radio.
- Permisos: administrador autorizado en operaciones de gerencia del módulo; superusuario sin restricciones de asignación propias del operario. Las plantillas evalúan el valor real de los permisos reactivos.
- Lotes: administrador/superusuario puede ser responsable. Se rechazan recibos repetidos o anulados y sobreasignaciones. Se bloquean filas de recibos al asignar cantidades para evitar consumo concurrente en PostgreSQL.
- Recibos: se mantiene la liquidación existente con fecha, referencia, comprobante, nota e importe. El estado visible es Cancelado; el campo técnico `liquidado` se conserva por compatibilidad y no se mezcla con el estado de procesamiento del café.
- Finca: nuevo indicador de ventas cobradas basado en importes reales de recibos cancelados de esa finca; pendiente de pago y número de recibos cancelados separados, con alcance de todo el historial.
- IA: se reparó el retorno de preparación de recibos, que había quedado fuera de su función. Se conservan tarjetas de confirmación de escrituras. Inventario ahora aporta faltantes y la última compra por insumo, con fecha, factura, moneda, unidad e impuestos. El agente debe distinguir estimaciones históricas de cotizaciones actuales.
- Alertas: canal interno disponible sin destinatarios externos; correo/Telegram opcionales. Se verificó deduplicación durante una condición persistente y rearme después de que deje de cumplirse.

## Verificación

- Backend: 41 pruebas aprobadas sobre SQLite temporal, sin escribir en producción ni enviar correos reales.
- Incluye administrador → recibo → lote → aprobación → solicitud de venta → lote vendido; rechazo de duplicación/sobreasignación y acceso de superusuario con rol base operario.
- Incluye liquidación y comprobantes, acciones de IA con confirmación, métricas de finca, humedad continua, reglas naturales, deduplicación y precios históricos.
- Frontend: compilación de producción correcta con Node 24; 13 pruebas de sesión aprobadas.
- Chrome: seis escenarios de login aprobados; cuatro escenarios de permisos (gerente, admin, superusuario, operario) aprobados, incluyendo apertura del diálogo de liquidación e indicador de finca.
- `git diff --check` correcto en ambos repositorios.

## Alcance pendiente y operación

- El intérprete de instrucciones naturales admite las reglas de días sin fertilizar y horas consecutivas de humedad alta. El constructor también permite programar otras métricas y umbrales. No existe todavía un evaluador general de cualquier condición escrita libremente ni una compilación automática de un prompt completo con múltiples reglas.
- Audio y respuestas generadas necesitan el proveedor de IA configurado. Se probaron herramientas y flujos con datos simulados; no se validaron transcripción ni recomendaciones contra el proveedor real.
- El monitoreo en segundo plano depende del servicio `notification-worker` de Docker Compose (`module_worker`), del módulo activo y de reglas habilitadas. Los avisos externos necesitan SMTP/Telegram configurados. No se arrancaron servicios productivos ni se enviaron notificaciones reales.
- `npm run typecheck` ya fallaba antes de esta revisión con 30 errores en ubicación, IoT, proveedores, capacitación, insumos y Flores del Volcán. La compilación pasa, pero no equivale a tener la comprobación completa de tipos en verde.
- La prueba de concurrencia real en PostgreSQL y la validación con datos productivos quedan pendientes; las pruebas automáticas usan SQLite aislado.

## Reproducir

Desde la raíz del workspace:

```sh
.venv/bin/python -m pytest backend/backend/api/tests -q
```

Desde `frontend/frontend`, con Node 24 disponible:

```sh
npm run build
node --test tests/auth.test.mjs
```

Las pruebas de navegador se describen en `frontend/frontend/tests/README.md`.
