"""FloresVolcan industry module."""
